# Janvi Gupta — Portfolio Starter Pack

This pack is prepared for use as a reference bundle in Google AI Studio.

## Files
- `prompts/MASTER-PROMPT.md` — paste this into Google AI Studio to start the first version.
- `content/portfolio-content.json` — structured content for the sections.
- `content/source-cv.docx` — original supplied CV for reference.
- `content/source-about-me.docx` — original supplied About Me text.
- `content/source-image-references.docx` — original image reference document.
- `assets/palette-reference.jpg` — palette image extracted from the reference document.
- `assets/signature-reference.jpg` — handwritten signature image extracted from the reference document.

## Why there is no CSV dataset
A CSV dataset is not needed for a personal portfolio. The information is structured content, not a dataset for analysis. JSON is a better fit for website copy and section data. No project data or credentials have been invented.

## Recommended Google AI Studio workflow
1. Start a new app/project.
2. Upload this ZIP or add the individual files, depending on the interface available.
3. Open `prompts/MASTER-PROMPT.md` and paste its contents into the app-building prompt.
4. Tell AI Studio to read `content/portfolio-content.json` and use the two images in `assets/` as references.
5. Review the generated site and correct any issues before publishing.
6. Add project-specific folders and case-study content later.

## Please verify before publishing
- The CV spells the first internship employer “Feliks Marketing LLP” and the second “Marched Solutions LLP”; confirm these spellings.
- Confirm the internship dates.
- The supplied CV and About Me document differ in the master's programme/institution details. The current About Me text supplied for this website says “Visual Experience Design at Karnavati University,” so the JSON uses that.
- The CV contains headings for Software Skills and AI Skills, but the specific names were not readable in the extracted text. Add the exact skills yourself.
- Choose which email address and whether any phone number should be publicly visible.
- The CV says “Graphic Design Intern” at Feliks Marketing LLP from May 2026 to August 2026. Confirm that these dates are correct before publishing.
